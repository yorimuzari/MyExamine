# My App

Paket siap-build hasil konversi HTML → aplikasi.

Isi folder:
- `www/` — berkas web Anda (dimuat oleh aplikasi)
- `electron/` — pembungkus aplikasi desktop Windows
- `scripts/` — penyesuaian otomatis proyek Android
- `.github/workflows/build.yml` — build otomatis di GitHub (gratis)

## Cara tercepat: build otomatis di GitHub
1. Buat repository baru di GitHub lalu unggah seluruh isi folder ini.
2. Buka tab **Actions** → pilih **Build My App** → **Run workflow**.
3. Tunggu selesai, lalu unduh hasilnya di bagian **Artifacts** (APK dan EXE).

## Build di komputer sendiri
```bash
npm install
npm run android:init && npm run android:apk   # butuh Android Studio / SDK + JDK 21
npm run desktop:exe                           # butuh Windows
```

Detail aplikasi:
- ID paket: `com.example.myapp`
- Versi: 1.0.0 (versionCode 1)
- Orientasi: default
- Izin Android: Akses internet, Status jaringan

> APK hasil workflow adalah versi **debug** (bisa langsung dipasang di HP). Untuk unggah ke Play Store, tanda tangani versi release dengan keystore Anda.
