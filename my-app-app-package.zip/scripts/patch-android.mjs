// Menyesuaikan proyek Android hasil 'npx cap add android'
import fs from "node:fs";

const manifestPath = "android/app/src/main/AndroidManifest.xml";
let xml = fs.readFileSync(manifestPath, "utf8");

const permissions = [
  "INTERNET",
  "ACCESS_NETWORK_STATE"
];
const tags = permissions
  .map((p) => `    <uses-permission android:name="android.permission.${p}" />`)
  .filter((t) => !xml.includes(t.trim()))
  .join("\n");
xml = xml.replace("</manifest>", tags + "\n</manifest>");

// orientasi mengikuti sistem


fs.writeFileSync(manifestPath, xml);

// Nama aplikasi & versi
const stringsPath = "android/app/src/main/res/values/strings.xml";
let strings = fs.readFileSync(stringsPath, "utf8");
strings = strings
  .replace(/(<string name="app_name">)[^<]*(<\/string>)/, '$1My App$2')
  .replace(/(<string name="title_activity_main">)[^<]*(<\/string>)/, '$1My App$2');
fs.writeFileSync(stringsPath, strings);

const gradlePath = "android/app/build.gradle";
let gradle = fs.readFileSync(gradlePath, "utf8");
gradle = gradle
  .replace(/versionCode \d+/, "versionCode 1")
  .replace(/versionName "[^"]*"/, 'versionName "1.0.0"');
fs.writeFileSync(gradlePath, gradle);

console.log("Proyek Android disesuaikan.");
